-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mer. 07 oct. 2026 à 13:47
-- Version du serveur : 8.4.7
-- Version de PHP : 8.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `atelier_mosaique`
--

-- --------------------------------------------------------

--
-- Structure de la table `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE IF NOT EXISTS `images` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` int NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `storage_name` varchar(40) NOT NULL,
  `mime_type` varchar(50) NOT NULL,
  `size_bytes` int UNSIGNED NOT NULL,
  `width` int UNSIGNED NOT NULL,
  `height` int UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `storage_name` (`storage_name`),
  KEY `idx_images_project_id` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `images`
--

INSERT INTO `images` (`id`, `project_id`, `original_name`, `storage_name`, `mime_type`, `size_bytes`, `width`, `height`, `created_at`) VALUES
(31, 9, 'face(1).png', '8902bfdb6b83ff5fad8bd3dce7545250.png', 'image/png', 49480, 319, 319, '2026-09-30 14:49:10'),
(32, 9, 'phone.png', '301701aa61568450c5952e0338d99aa3.png', 'image/png', 74711, 319, 319, '2026-09-30 14:49:10'),
(33, 9, 'pullgris.png', '60ad2315cc16001331cbb0dd4a0ffb38.png', 'image/png', 136198, 319, 319, '2026-09-30 14:49:10'),
(34, 9, 'pullpink.png', '2afba7bf528e70c0275f62807ad665f9.png', 'image/png', 109376, 319, 319, '2026-09-30 14:49:10'),
(35, 9, 'shirtbl.png', 'a61b72fe1682f09e2a1dac8502fc8746.png', 'image/png', 62416, 319, 319, '2026-09-30 14:49:10'),
(42, 1, '55277021312_6caae79d2f_c.jpg', '4f32616e3e97ecbb06d704ef5bf5e911.jpg', 'image/jpeg', 127372, 800, 534, '2026-10-07 12:09:45'),
(43, 1, '55277023707_327b8841ae_c.jpg', '20a7f92ffbb31ca390dd42ad8f18f019.jpg', 'image/jpeg', 109495, 799, 533, '2026-10-07 12:09:45'),
(44, 1, '55277940491_3cea66ca41_c.jpg', 'bf787e4a6865cf6b4d87f826c18b3dd3.jpg', 'image/jpeg', 90864, 800, 534, '2026-10-07 12:09:45'),
(45, 1, '55277940571_4409e1d0ee_c.jpg', 'cd2a6f9ebc241dde506ab1621339f548.jpg', 'image/jpeg', 188764, 800, 534, '2026-10-07 12:09:45'),
(46, 1, '55277940636_c4d2e2429b_c.jpg', '57761850e6bb49e64c8de446ce6ab50d.jpg', 'image/jpeg', 121850, 800, 534, '2026-10-07 12:09:45'),
(47, 2, '55278292690_973f86e449_c.jpg', 'd967defb6c2bf9e917bdb1ecac48166d.jpg', 'image/jpeg', 166598, 799, 533, '2026-10-07 12:15:50'),
(48, 2, '55278033693_1539b5cc32_c.jpg', '77622dafa929fcacd6029956c5aa04be.jpg', 'image/jpeg', 82036, 800, 534, '2026-10-07 12:15:50'),
(49, 2, '55278033713_cd444699a7_c.jpg', '4ce094c04d2ba7e114b500fc59c70b35.jpg', 'image/jpeg', 149869, 799, 533, '2026-10-07 12:15:50'),
(50, 2, '55278033758_bdab077ccf_c.jpg', '49f2d8e68121a5d97529b6f454306253.jpg', 'image/jpeg', 100834, 800, 534, '2026-10-07 12:15:50'),
(51, 2, '55278033808_2e2e0fbb8d_c.jpg', 'ee0139eebac463bfa7ec33c852c935c2.jpg', 'image/jpeg', 124380, 533, 799, '2026-10-07 12:15:59'),
(52, 2, '55278128994_3f0ff8920c_c.jpg', '9dc34020c987e7f952c92441e881743a.jpg', 'image/jpeg', 183550, 800, 800, '2026-10-07 12:15:59'),
(53, 2, '55278033948_ba042929d5_c.jpg', '7e86b09ce01338849b7b746a889fe6f5.jpg', 'image/jpeg', 131740, 799, 533, '2026-10-07 12:15:59'),
(54, 2, '55276984652_30bde93615_c.jpg', 'a1043cdbc76e1f3b599ffc55459f1f89.jpg', 'image/jpeg', 149121, 800, 534, '2026-10-07 12:15:59'),
(55, 2, '55278033808_2e2e0fbb8d_c.jpg', '655cc3150a72c66bb7f38afaf10131cd.jpg', 'image/jpeg', 124380, 533, 799, '2026-10-07 12:16:12'),
(56, 2, '55278128994_3f0ff8920c_c.jpg', 'df652ded722e607a3a600ec124519cf4.jpg', 'image/jpeg', 183550, 800, 800, '2026-10-07 12:16:12'),
(57, 2, '55278033948_ba042929d5_c.jpg', 'db6c094e523684da00e7b185eab0ca3d.jpg', 'image/jpeg', 131740, 799, 533, '2026-10-07 12:16:12'),
(58, 2, '55276984652_30bde93615_c.jpg', '83fa8a0e72c10210ef9e055561aecbb2.jpg', 'image/jpeg', 149121, 800, 534, '2026-10-07 12:16:12'),
(59, 2, '55276984802_5e80cff511_c.jpg', '74ef9593d19138226f94626f37664db2.jpg', 'image/jpeg', 80568, 534, 800, '2026-10-07 12:16:27'),
(60, 2, '55278129344_bc96629193_c.jpg', 'd3dd5f90f602d948387cb812bd3bf789.jpg', 'image/jpeg', 104840, 534, 800, '2026-10-07 12:16:27'),
(61, 2, '55276984992_a654bfc4f1_c.jpg', '38b035d9fe0f565e9b3b98a2e595afa7.jpg', 'image/jpeg', 101897, 534, 800, '2026-10-07 12:16:27'),
(62, 2, '55277904636_8152fe42fe_c.jpg', '67a8bd7244bf38267fe6de557f20fe42.jpg', 'image/jpeg', 119759, 533, 799, '2026-10-07 12:16:27'),
(63, 2, '55276984992_a654bfc4f1_c.jpg', '5df977c89daad9d2f0bfd9ed8fdf3d10.jpg', 'image/jpeg', 101897, 534, 800, '2026-10-07 12:16:38'),
(64, 2, '55277904636_8152fe42fe_c.jpg', '17d1b66f61f1c9aa57d6077d81138325.jpg', 'image/jpeg', 119759, 533, 799, '2026-10-07 12:16:38'),
(65, 2, '55278034378_6f6aa0a194_c.jpg', '5daf5f79695ccae0c7c195649fdba0ae.jpg', 'image/jpeg', 118191, 799, 533, '2026-10-07 12:16:38'),
(66, 2, '55277904691_e197cc9062_c.jpg', 'ef68b2fcd320e26521e1bff008f58f85.jpg', 'image/jpeg', 153802, 799, 533, '2026-10-07 12:16:38'),
(67, 3, '54484861425_b7ddecadd3_k.jpg', 'd94bb01405c6f46d44b3b7fb1e9b9a0b.jpg', 'image/jpeg', 565351, 2048, 1365, '2026-10-07 13:06:45'),
(68, 3, '54484503606_bf561db98b_k.jpg', '7d02b5be9fdb7db320019717d23e6c34.jpg', 'image/jpeg', 743777, 2048, 1365, '2026-10-07 13:06:45'),
(69, 3, '54484503706_182024b7d5_k.jpg', '4b775d8591f51df0f4f9e806a0321461.jpg', 'image/jpeg', 851387, 2048, 1365, '2026-10-07 13:06:45'),
(70, 3, '54484782303_a4b644ca49_k.jpg', '5c1208c9bfd2d979f0bca1e3192b9a0d.jpg', 'image/jpeg', 434892, 2048, 1365, '2026-10-07 13:06:45'),
(71, 3, '54484860260_5a09d98618_k.jpg', 'e0fe55124e64318db4cc1023a54bc3d5.jpg', 'image/jpeg', 530501, 2048, 1365, '2026-10-07 13:06:45');

-- --------------------------------------------------------

--
-- Structure de la table `projects`
--

DROP TABLE IF EXISTS `projects`;
CREATE TABLE IF NOT EXISTS `projects` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mosaic_width` smallint UNSIGNED NOT NULL DEFAULT '1400',
  `mosaic_height` smallint UNSIGNED NOT NULL DEFAULT '900',
  `mosaic_mode` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal',
  `mosaic_gap` tinyint UNSIGNED NOT NULL DEFAULT '8',
  `mosaic_radius` smallint UNSIGNED NOT NULL DEFAULT '12',
  `mosaic_bg` char(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#12121a',
  `mosaic_bg_transparent` tinyint UNSIGNED NOT NULL DEFAULT '0',
  `mosaic_margin` smallint UNSIGNED NOT NULL DEFAULT '0',
  `mosaic_seed` bigint UNSIGNED DEFAULT NULL,
  `archived_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `projects`
--

INSERT INTO `projects` (`id`, `name`, `mosaic_width`, `mosaic_height`, `mosaic_mode`, `mosaic_gap`, `mosaic_radius`, `mosaic_bg`, `mosaic_bg_transparent`, `mosaic_margin`, `mosaic_seed`, `archived_at`) VALUES
(1, '40e Festival Bruxelles Babel - Vernissage expo', 1200, 950, 'normal', 8, 12, '#12121a', 0, 0, 1655563039, NULL),
(2, '40e Festival Bruxelles Babel 2026', 1400, 900, 'normal', 8, 12, '#12121a', 0, 0, NULL, NULL),
(3, '39è Festival Bruxelles Babel 2025 - Vernissage expo', 1400, 900, 'normal', 8, 12, '#12121a', 0, 0, NULL, NULL),
(4, '38è Festival Bruxelles Babel 2024', 1200, 600, 'normal', 8, 16, '#ffffff', 1, 30, 564605520, NULL),
(5, '38e Festival Bruxelles Babel - Rencontre Babel 1 2024', 1400, 900, 'normal', 8, 12, '#12121a', 0, 0, NULL, NULL),
(9, 'Merch fally', 1400, 900, 'normal', 8, 12, '#12121a', 0, 0, NULL, '2026-10-07 13:12:40'),
(12, 'baba', 1400, 900, 'normal', 8, 12, '#12121a', 0, 0, NULL, '2026-10-07 10:21:11');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `images`
--
ALTER TABLE `images`
  ADD CONSTRAINT `fk_images_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
